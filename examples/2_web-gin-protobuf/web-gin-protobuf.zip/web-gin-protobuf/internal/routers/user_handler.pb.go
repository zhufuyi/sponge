package routers

import (
	userV1 "user/api/user/v1"
	"user/internal/handler"

	"github.com/zhufuyi/sponge/pkg/logger"

	"github.com/gin-gonic/gin"
)

func init() {
	apiV1RouterFns = append(apiV1RouterFns, func(prePath string, group *gin.RouterGroup) {
		userRouter(prePath, group, handler.NewUserHandler())
	})
}

func userRouter(prePath string, group *gin.RouterGroup, iService userV1.UserLogicer) {
	userV1.RegisterUserRouter(prePath, group, iService,
		userV1.WithUserRPCResponse(),
		userV1.WithUserLogger(logger.Get()),
	)
}
