package routers

import (
	"context"
	"testing"
	"time"

	userV1 "user/api/user/v1"
	"user/configs"
	"user/internal/config"

	"github.com/zhufuyi/sponge/pkg/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestNewRouter(t *testing.T) {
	err := config.Init(configs.Path("user.yml"))
	if err != nil {
		t.Fatal(err)
	}

	config.Get().App.EnableMetrics = true
	config.Get().App.EnableTrace = true
	config.Get().App.EnableHTTPProfile = true
	config.Get().App.EnableLimit = true
	config.Get().App.EnableCircuitBreaker = true

	utils.SafeRunWithTimeout(time.Second*2, func(cancel context.CancelFunc) {
		gin.SetMode(gin.ReleaseMode)
		r := NewRouter()
		assert.NotNil(t, r)
		cancel()
	})
}

func Test_userExampleServiceRouter(t *testing.T) {
	gin.SetMode(gin.ReleaseMode)
	r := gin.Default()
	rg := r.Group("")
	userExampleServiceRouter("", rg, &mockGw{})
}

type mockGw struct{}

func (m mockGw) Create(ctx context.Context, req *userV1.CreateUserExampleRequest) (*userV1.CreateUserExampleReply, error) {
	return nil, nil
}

func (m mockGw) DeleteByID(ctx context.Context, req *userV1.DeleteUserExampleByIDRequest) (*userV1.DeleteUserExampleByIDReply, error) {
	return nil, nil
}

func (m mockGw) GetByID(ctx context.Context, req *userV1.GetUserExampleByIDRequest) (*userV1.GetUserExampleByIDReply, error) {
	return nil, nil
}

func (m mockGw) List(ctx context.Context, req *userV1.ListUserExampleRequest) (*userV1.ListUserExampleReply, error) {
	return nil, nil
}

func (m mockGw) ListByIDs(ctx context.Context, req *userV1.ListUserExampleByIDsRequest) (*userV1.ListUserExampleByIDsReply, error) {
	return nil, nil
}

func (m mockGw) UpdateByID(ctx context.Context, req *userV1.UpdateUserExampleByIDRequest) (*userV1.UpdateUserExampleByIDReply, error) {
	return nil, nil
}
