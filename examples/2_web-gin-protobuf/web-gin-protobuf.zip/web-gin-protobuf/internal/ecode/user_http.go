package ecode

import (
	"github.com/zhufuyi/sponge/pkg/errcode"
)

// user http service level error code
var (
	userNO       = 36 // number range 1~100, if there is the same number, trigger panic.
	userName     = "user"
	userBaseCode = errcode.HCode(userNO)

	ErrRegisterUser   = errcode.NewError(userBaseCode+1, "failed to Register "+userName)
	ErrLoginUser   = errcode.NewError(userBaseCode+2, "failed to Login "+userName)
	// add +1 to the previous error code
)
