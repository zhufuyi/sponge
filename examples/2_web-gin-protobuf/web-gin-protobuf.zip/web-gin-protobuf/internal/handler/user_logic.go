package handler

import (
	"context"

	userV1 "user/api/user/v1"

	//"github.com/zhufuyi/sponge/pkg/gin/middleware"
)

var _ userV1.UserLogicer = (*userHandler)(nil)

type userHandler struct {
	// example: 
	// 	userDao dao.UserDao
}

// NewUserHandler creating handler
func NewUserHandler() userV1.UserLogicer {
	return &userHandler{
		// example:
		// 	userDao: dao.NewUserDao(
		// 		model.GetDB(),
		// 		cache.NewUserCache(model.GetCacheType()),
		// 	),
	}
}

func (h *userHandler) Register(ctx context.Context, req *userV1.RegisterRequest) (*userV1.RegisterReply, error) {
	// example:
	// 	reply, err := h.userDao.Register(ctx, req)
	// 	if err != nil {
	//			logger.Warn("Register error", logger.Err(err), middleware.CtxRequestIDField(ctx))
	//			return nil, ecode.InternalServerError.Err()
	//		}
	// 	return reply, nil

	// fill in the business logic code

	panic("implement me")
}

func (h *userHandler) Login(ctx context.Context, req *userV1.LoginRequest) (*userV1.LoginReply, error) {
	// example:
	// 	reply, err := h.userDao.Login(ctx, req)
	// 	if err != nil {
	//			logger.Warn("Login error", logger.Err(err), middleware.CtxRequestIDField(ctx))
	//			return nil, ecode.InternalServerError.Err()
	//		}
	// 	return reply, nil

	// fill in the business logic code

	panic("implement me")
}
