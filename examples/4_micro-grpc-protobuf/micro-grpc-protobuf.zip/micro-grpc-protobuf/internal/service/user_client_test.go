package service

import (
	"context"
	"encoding/json"
	"fmt"
	"testing"
	"time"

	userV1 "user/api/user/v1"
	"user/configs"
	"user/internal/config"

	"github.com/zhufuyi/sponge/pkg/grpc/benchmark"
)

// Test each method of user via the rpc client
func Test_service_user_methods(t *testing.T) {
	conn := getRPCClientConnForTest()
	cli := userV1.NewUserClient(conn)
	ctx, _ := context.WithTimeout(context.Background(), time.Second*5)

	tests := []struct {
		name    string
		fn      func() (interface{}, error)
		wantErr bool
	}{
		{
			name: "Register",
			fn: func() (interface{}, error) {
				// todo type in the parameters to test
				req := &userV1.RegisterRequest{
					Email: "", 
					Password: "", 
				}
				return cli.Register(ctx, req)
			},
			wantErr: false,
		},
		{
			name: "Login",
			fn: func() (interface{}, error) {
				// todo type in the parameters to test
				req := &userV1.LoginRequest{
					Email: "", 
					Password: "", 
				}
				return cli.Login(ctx, req)
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.fn()
			if (err != nil) != tt.wantErr {
				t.Errorf("test '%s' error = %v, wantErr %v", tt.name, err, tt.wantErr)
				return
			}
			data, _ := json.MarshalIndent(got, "", "    ")
			fmt.Println(string(data))
		})
	}
}

// Perform a stress test on user's method and 
// copy the press test report to your browser when you are finished.
func Test_service_user_benchmark(t *testing.T) {
	err := config.Init(configs.Path("user.yml"))
	if err != nil {
		panic(err)
	}
	host := fmt.Sprintf("127.0.0.1:%d", config.Get().Grpc.Port)
	protoFile := configs.Path("../api/user/v1/user.proto")
	// If third-party dependencies are missing during the press test,
	// copy them to the project's third_party directory.
	importPaths := []string{
		configs.Path("../third_party"), // third_party directory
		configs.Path(".."),             // Previous level of third_party
	}

	tests := []struct {
		name    string
		fn      func() error
		wantErr bool
	}{
		{
			name: "Register",
			fn: func() error {
				// todo type in the parameters to test
				message := &userV1.RegisterRequest{
					Email: "", 
					Password: "", 
				}
				var total uint = 1000 // total number of requests
				b, err := benchmark.New(host, protoFile, "Register", message, total, importPaths...)
				if err != nil {
					return err
				}
				return b.Run()
			},
			wantErr: false,
		},
		{
			name: "Login",
			fn: func() error {
				// todo type in the parameters to test
				message := &userV1.LoginRequest{
					Email: "", 
					Password: "", 
				}
				var total uint = 1000 // total number of requests
				b, err := benchmark.New(host, protoFile, "Login", message, total, importPaths...)
				if err != nil {
					return err
				}
				return b.Run()
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := tt.fn()
			if (err != nil) != tt.wantErr {
				t.Errorf("test '%s' error = %v, wantErr %v", tt.name, err, tt.wantErr)
				return
			}
		})
	}
}
