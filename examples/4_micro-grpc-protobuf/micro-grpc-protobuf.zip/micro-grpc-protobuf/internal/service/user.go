package service

import (
	"context"

	userV1 "user/api/user/v1"

	//"user/internal/cache"
	//"user/internal/dao"
	//"user/internal/ecode"
	//"user/internal/model"

	//"github.com/zhufuyi/sponge/pkg/grpc/interceptor"
	//"github.com/zhufuyi/sponge/pkg/logger"

	"google.golang.org/grpc"
)

func init() {
	registerFns = append(registerFns, func(server *grpc.Server) {
		userV1.RegisterUserServer(server, NewUserServer())
	})
}

var _ userV1.UserServer = (*user)(nil)

type user struct {
	userV1.UnimplementedUserServer

	// example:
	//	iDao dao.UserDao
}

// NewUserServer create a server
func NewUserServer() userV1.UserServer {
	return &user{
		// example:
		//	iDao: dao.NewUserDao(
		//		model.GetDB(),
		//		cache.NewUserCache(model.GetCacheType()),
		//	),
	}
}

func (s *user) Register(ctx context.Context, req *userV1.RegisterRequest) (*userV1.RegisterReply, error) {
	// example:
	//	    err := req.Validate()
	//	    if err != nil {
	//		    logger.Warn("req.Validate error", logger.Err(err), logger.Any("req", req), interceptor.ServerCtxRequestIDField(ctx))
	//		    return nil, ecode.StatusInvalidParams.Err()
	//	    }
    //
	// 	reply, err := s.xxxDao.XxxMethod(ctx, req)
	// 	if err != nil {
	//			logger.Warn("XxxMethod error", logger.Err(err), interceptor.ServerCtxRequestIDField(ctx))
	//			return nil, ecode.InternalServerError.Err()
	//		}
	// 	return reply, nil

	// fill in the business logic code

	panic("implement me")
}

func (s *user) Login(ctx context.Context, req *userV1.LoginRequest) (*userV1.LoginReply, error) {
	// example:
	//	    err := req.Validate()
	//	    if err != nil {
	//		    logger.Warn("req.Validate error", logger.Err(err), logger.Any("req", req), interceptor.ServerCtxRequestIDField(ctx))
	//		    return nil, ecode.StatusInvalidParams.Err()
	//	    }
    //
	// 	reply, err := s.xxxDao.XxxMethod(ctx, req)
	// 	if err != nil {
	//			logger.Warn("XxxMethod error", logger.Err(err), interceptor.ServerCtxRequestIDField(ctx))
	//			return nil, ecode.InternalServerError.Err()
	//		}
	// 	return reply, nil

	// fill in the business logic code

	panic("implement me")
}
