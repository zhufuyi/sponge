package service

import (
	"testing"
	"time"

	"user/api/types"
	userV1 "user/api/user/v1"
	"user/internal/cache"
	"user/internal/dao"
	"user/internal/model"

	"github.com/zhufuyi/sponge/pkg/gotest"
	"github.com/zhufuyi/sponge/pkg/utils"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/jinzhu/copier"
	"github.com/stretchr/testify/assert"
)

func newTeacherService() *gotest.Service {
	// todo additional test field information
	testData := &model.Teacher{}
	testData.ID = 1
	testData.CreatedAt = time.Now()
	testData.UpdatedAt = testData.CreatedAt

	// init mock cache
	c := gotest.NewCache(map[string]interface{}{utils.Uint64ToStr(testData.ID): testData})
	c.ICache = cache.NewTeacherCache(&model.CacheType{
		CType: "redis",
		Rdb:   c.RedisClient,
	})

	// init mock dao
	d := gotest.NewDao(c, testData)
	d.IDao = dao.NewTeacherDao(d.DB, c.ICache.(cache.TeacherCache))

	// init mock service
	s := gotest.NewService(d, testData)
	userV1.RegisterTeacherServiceServer(s.Server, &teacherService{
		UnimplementedTeacherServiceServer: userV1.UnimplementedTeacherServiceServer{},
		iDao:                              d.IDao.(dao.TeacherDao),
	})

	// start up rpc server
	s.GoGrpcServer()
	time.Sleep(time.Millisecond * 100)

	// grpc client
	s.IServiceClient = userV1.NewTeacherServiceClient(s.GetClientConn())

	return s
}

func Test_teacherService_Create(t *testing.T) {
	s := newTeacherService()
	defer s.Close()
	testData := &userV1.CreateTeacherRequest{}
	_ = copier.Copy(testData, s.TestData.(*model.Teacher))

	s.MockDao.SQLMock.ExpectBegin()
	args := s.MockDao.GetAnyArgs(s.TestData)
	s.MockDao.SQLMock.ExpectExec("INSERT INTO .*").
		WithArgs(args[:len(args)-1]...). // Modified according to the actual number of parameters
		WillReturnResult(sqlmock.NewResult(1, 1))
	s.MockDao.SQLMock.ExpectCommit()

	reply, err := s.IServiceClient.(userV1.TeacherServiceClient).Create(s.Ctx, testData)
	t.Log(err, reply.String())

}

func Test_teacherService_DeleteByID(t *testing.T) {
	s := newTeacherService()
	defer s.Close()
	testData := &userV1.DeleteTeacherByIDRequest{
		Id: s.TestData.(*model.Teacher).ID,
	}

	s.MockDao.SQLMock.ExpectBegin()
	s.MockDao.SQLMock.ExpectExec("UPDATE .*").
		WithArgs(s.MockDao.AnyTime, testData.Id). // Modified according to the actual number of parameters
		WillReturnResult(sqlmock.NewResult(int64(testData.Id), 1))
	s.MockDao.SQLMock.ExpectCommit()

	reply, err := s.IServiceClient.(userV1.TeacherServiceClient).DeleteByID(s.Ctx, testData)
	assert.NoError(t, err)
	t.Log(reply.String())

	// zero id error test
	testData.Id = 0
	reply, err = s.IServiceClient.(userV1.TeacherServiceClient).DeleteByID(s.Ctx, testData)
	assert.Error(t, err)

	// delete error test
	testData.Id = 111
	reply, err = s.IServiceClient.(userV1.TeacherServiceClient).DeleteByID(s.Ctx, testData)
	assert.Error(t, err)
}

func Test_teacherService_UpdateByID(t *testing.T) {
	s := newTeacherService()
	defer s.Close()
	data := s.TestData.(*model.Teacher)
	testData := &userV1.UpdateTeacherByIDRequest{}
	_ = copier.Copy(testData, s.TestData.(*model.Teacher))
	testData.Id = data.ID

	s.MockDao.SQLMock.ExpectBegin()
	s.MockDao.SQLMock.ExpectExec("UPDATE .*").
		WithArgs(s.MockDao.AnyTime, testData.Id). // Modified according to the actual number of parameters
		WillReturnResult(sqlmock.NewResult(int64(testData.Id), 1))
	s.MockDao.SQLMock.ExpectCommit()

	reply, err := s.IServiceClient.(userV1.TeacherServiceClient).UpdateByID(s.Ctx, testData)
	assert.NoError(t, err)
	t.Log(reply.String())

	// zero id error test
	testData.Id = 0
	reply, err = s.IServiceClient.(userV1.TeacherServiceClient).UpdateByID(s.Ctx, testData)
	assert.Error(t, err)

	// upate error test
	testData.Id = 111
	reply, err = s.IServiceClient.(userV1.TeacherServiceClient).UpdateByID(s.Ctx, testData)
	assert.Error(t, err)
}

func Test_teacherService_GetByID(t *testing.T) {
	s := newTeacherService()
	defer s.Close()
	data := s.TestData.(*model.Teacher)
	testData := &userV1.GetTeacherByIDRequest{
		Id: data.ID,
	}

	rows := sqlmock.NewRows([]string{"id", "created_at", "updated_at"}).
		AddRow(data.ID, data.CreatedAt, data.UpdatedAt)

	s.MockDao.SQLMock.ExpectQuery("SELECT .*").
		WithArgs(testData.Id).
		WillReturnRows(rows)

	reply, err := s.IServiceClient.(userV1.TeacherServiceClient).GetByID(s.Ctx, testData)
	assert.NoError(t, err)
	t.Log(reply.String())

	// zero id error test
	testData.Id = 0
	reply, err = s.IServiceClient.(userV1.TeacherServiceClient).GetByID(s.Ctx, testData)
	assert.Error(t, err)

	// get error test
	testData.Id = 111
	reply, err = s.IServiceClient.(userV1.TeacherServiceClient).GetByID(s.Ctx, testData)
	assert.Error(t, err)
}

func Test_teacherService_ListByIDs(t *testing.T) {
	s := newTeacherService()
	defer s.Close()
	data := s.TestData.(*model.Teacher)
	testData := &userV1.ListTeacherByIDsRequest{
		Ids: []uint64{data.ID},
	}

	rows := sqlmock.NewRows([]string{"id", "created_at", "updated_at"}).
		AddRow(data.ID, data.CreatedAt, data.UpdatedAt)

	s.MockDao.SQLMock.ExpectQuery("SELECT .*").
		WithArgs(data.ID).
		WillReturnRows(rows)

	reply, err := s.IServiceClient.(userV1.TeacherServiceClient).ListByIDs(s.Ctx, testData)
	assert.NoError(t, err)
	t.Log(reply.String())

	// get error test
	testData.Ids = []uint64{111}
	reply, err = s.IServiceClient.(userV1.TeacherServiceClient).ListByIDs(s.Ctx, testData)
	assert.Error(t, err)
}

func Test_teacherService_List(t *testing.T) {
	s := newTeacherService()
	defer s.Close()
	testData := s.TestData.(*model.Teacher)

	rows := sqlmock.NewRows([]string{"id", "created_at", "updated_at"}).
		AddRow(testData.ID, testData.CreatedAt, testData.UpdatedAt)

	s.MockDao.SQLMock.ExpectQuery("SELECT .*").WillReturnRows(rows)

	reply, err := s.IServiceClient.(userV1.TeacherServiceClient).List(s.Ctx, &userV1.ListTeacherRequest{
		Params: &types.Params{
			Page:  0,
			Limit: 10,
			Sort:  "ignore count", // ignore test count
		},
	})
	assert.NoError(t, err)
	t.Log(reply.String())

	// get error test
	reply, err = s.IServiceClient.(userV1.TeacherServiceClient).List(s.Ctx, &userV1.ListTeacherRequest{
		Params: &types.Params{
			Page:  0,
			Limit: 10,
		},
	})
	assert.Error(t, err)
}

func Test_covertTeacher(t *testing.T) {
	testData := &model.Teacher{}
	testData.ID = 1
	testData.CreatedAt = time.Now()
	testData.UpdatedAt = testData.CreatedAt

	data, err := covertTeacher(testData)
	assert.NoError(t, err)

	t.Logf("%+v", data)
}
