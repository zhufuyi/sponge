package service

import (
	"context"

	commentV1 "comment/api/comment/v1"

	//"comment/internal/cache"
	//"comment/internal/dao"
	//"comment/internal/ecode"
	//"comment/internal/model"

	//"github.com/zhufuyi/sponge/pkg/grpc/interceptor"
	//"github.com/zhufuyi/sponge/pkg/logger"

	"google.golang.org/grpc"
)

func init() {
	registerFns = append(registerFns, func(server *grpc.Server) {
		commentV1.RegisterCommentServer(server, NewCommentServer())
	})
}

var _ commentV1.CommentServer = (*comment)(nil)

type comment struct {
	commentV1.UnimplementedCommentServer

	// example:
	//	iDao dao.CommentDao
}

// NewCommentServer create a server
func NewCommentServer() commentV1.CommentServer {
	return &comment{
		// example:
		//	iDao: dao.NewCommentDao(
		//		model.GetDB(),
		//		cache.NewCommentCache(model.GetCacheType()),
		//	),
	}
}

func (s *comment) ListByProductID(ctx context.Context, req *commentV1.ListByProductIDRequest) (*commentV1.ListByProductIDReply, error) {
	// example:
	//	    err := req.Validate()
	//	    if err != nil {
	//		    logger.Warn("req.Validate error", logger.Err(err), logger.Any("req", req), interceptor.ServerCtxRequestIDField(ctx))
	//		    return nil, ecode.StatusInvalidParams.Err()
	//	    }
	//
	// 	reply, err := s.xxxDao.XxxMethod(ctx, req)
	// 	if err != nil {
	//			logger.Warn("XxxMethod error", logger.Err(err), interceptor.ServerCtxRequestIDField(ctx))
	//			return nil, ecode.InternalServerError.Err()
	//		}
	// 	return reply, nil

	// fill in the business logic code

	return &commentV1.ListByProductIDReply{
		Total:     3,
		ProductID: 1,
		CommentDetails: []*commentV1.CommentDetail{
			{
				Id:       1,
				Username: "Mr Zhang",
				Content:  "good",
			},
			{
				Id:       2,
				Username: "Mr Li",
				Content:  "good",
			},
			{
				Id:       3,
				Username: "Mr Wang",
				Content:  "not good",
			},
		},
	}, nil

}
