package routers

import (
	"context"
	"testing"
	"time"

	shopgwV1 "shopgw/api/shopgw/v1"
	"shopgw/configs"
	"shopgw/internal/config"

	"github.com/zhufuyi/sponge/pkg/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestNewRouter(t *testing.T) {
	err := config.Init(configs.Path("shopgw.yml"))
	if err != nil {
		t.Fatal(err)
	}

	config.Get().App.EnableMetrics = true
	config.Get().App.EnableTrace = true
	config.Get().App.EnableHTTPProfile = true
	config.Get().App.EnableLimit = true
	config.Get().App.EnableCircuitBreaker = true

	utils.SafeRunWithTimeout(time.Second*2, func(cancel context.CancelFunc) {
		gin.SetMode(gin.ReleaseMode)
		r := NewRouter()
		assert.NotNil(t, r)
		cancel()
	})
}

func Test_userExampleServiceRouter(t *testing.T) {
	gin.SetMode(gin.ReleaseMode)
	r := gin.Default()
	userExampleServiceRouter(r, &mockGw{})
}

type mockGw struct{}

func (m mockGw) Create(ctx context.Context, req *shopgwV1.CreateUserExampleRequest) (*shopgwV1.CreateUserExampleReply, error) {
	return nil, nil
}

func (m mockGw) DeleteByID(ctx context.Context, req *shopgwV1.DeleteUserExampleByIDRequest) (*shopgwV1.DeleteUserExampleByIDReply, error) {
	return nil, nil
}

func (m mockGw) GetByID(ctx context.Context, req *shopgwV1.GetUserExampleByIDRequest) (*shopgwV1.GetUserExampleByIDReply, error) {
	return nil, nil
}

func (m mockGw) List(ctx context.Context, req *shopgwV1.ListUserExampleRequest) (*shopgwV1.ListUserExampleReply, error) {
	return nil, nil
}

func (m mockGw) ListByIDs(ctx context.Context, req *shopgwV1.ListUserExampleByIDsRequest) (*shopgwV1.ListUserExampleByIDsReply, error) {
	return nil, nil
}

func (m mockGw) UpdateByID(ctx context.Context, req *shopgwV1.UpdateUserExampleByIDRequest) (*shopgwV1.UpdateUserExampleByIDReply, error) {
	return nil, nil
}
