package routers

import (
	shopgwV1 "shopgw/api/shopgw/v1"
	"shopgw/internal/service"

	"github.com/zhufuyi/sponge/pkg/logger"

	"github.com/gin-gonic/gin"
)

func init() {
	rootRouterFns = append(rootRouterFns, func(r *gin.Engine) {
		shopGwRouter(r, service.NewShopGwClient())
	})
}

func shopGwRouter(r *gin.Engine, iService shopgwV1.ShopGwLogicer) {
	shopgwV1.RegisterShopGwRouter(r, iService,
		shopgwV1.WithShopGwRPCResponse(),
		shopgwV1.WithShopGwLogger(logger.Get()),
	)
}
