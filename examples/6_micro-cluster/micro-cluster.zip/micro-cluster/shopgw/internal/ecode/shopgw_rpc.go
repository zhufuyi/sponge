package ecode

import (
	"github.com/zhufuyi/sponge/pkg/errcode"
)

// shopGw rpc service level error code
var (
	_shopGwNO       = 88 // number range 1~100, if there is the same number, trigger panic.
	_shopGwName     = "shopGw"
	_shopGwBaseCode = errcode.HCode(_shopGwNO)

	StatusGetDetailsByProductIDShopGw   = errcode.NewError(_shopGwBaseCode+1, "failed to GetDetailsByProductID "+_shopGwName)
	// add +1 to the previous error code
)
