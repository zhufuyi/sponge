package ecode

import (
	"github.com/zhufuyi/sponge/pkg/errcode"
)

// product rpc service level error code
var (
	_productNO       = 97 // number range 1~100, if there is the same number, trigger panic.
	_productName     = "product"
	_productBaseCode = errcode.HCode(_productNO)

	StatusGetByIDProduct   = errcode.NewError(_productBaseCode+1, "failed to GetByID "+_productName)
	// add +1 to the previous error code
)
