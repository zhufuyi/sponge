package service

import (
	"context"

	inventoryV1 "inventory/api/inventory/v1"

	//"inventory/internal/cache"
	//"inventory/internal/dao"
	//"inventory/internal/ecode"
	//"inventory/internal/model"

	//"github.com/zhufuyi/sponge/pkg/grpc/interceptor"
	//"github.com/zhufuyi/sponge/pkg/logger"

	"google.golang.org/grpc"
)

func init() {
	registerFns = append(registerFns, func(server *grpc.Server) {
		inventoryV1.RegisterInventoryServer(server, NewInventoryServer())
	})
}

var _ inventoryV1.InventoryServer = (*inventory)(nil)

type inventory struct {
	inventoryV1.UnimplementedInventoryServer

	// example:
	//	iDao dao.InventoryDao
}

// NewInventoryServer create a server
func NewInventoryServer() inventoryV1.InventoryServer {
	return &inventory{
		// example:
		//	iDao: dao.NewInventoryDao(
		//		model.GetDB(),
		//		cache.NewInventoryCache(model.GetCacheType()),
		//	),
	}
}

func (s *inventory) GetByID(ctx context.Context, req *inventoryV1.GetByIDRequest) (*inventoryV1.GetByIDReply, error) {
	// example:
	//	    err := req.Validate()
	//	    if err != nil {
	//		    logger.Warn("req.Validate error", logger.Err(err), logger.Any("req", req), interceptor.ServerCtxRequestIDField(ctx))
	//		    return nil, ecode.StatusInvalidParams.Err()
	//	    }
	//
	// 	reply, err := s.xxxDao.XxxMethod(ctx, req)
	// 	if err != nil {
	//			logger.Warn("XxxMethod error", logger.Err(err), interceptor.ServerCtxRequestIDField(ctx))
	//			return nil, ecode.InternalServerError.Err()
	//		}
	// 	return reply, nil

	// fill in the business logic code

	return &inventoryV1.GetByIDReply{
		InventoryDetail: &inventoryV1.InventoryDetail{
			Id:      1,
			Num:     999,
			SoldNum: 111,
		},
	}, nil

}
