package ecode

import (
	"github.com/zhufuyi/sponge/pkg/errcode"
)

// inventory rpc service level error code
var (
	_inventoryNO       = 97 // number range 1~100, if there is the same number, trigger panic.
	_inventoryName     = "inventory"
	_inventoryBaseCode = errcode.HCode(_inventoryNO)

	StatusGetByIDInventory   = errcode.NewError(_inventoryBaseCode+1, "failed to GetByID "+_inventoryName)
	// add +1 to the previous error code
)
