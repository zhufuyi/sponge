
copy the configuration file to the configs directory and binary file before starting the service.

```
├── configs
│         └── inventory.yml
├── inventory
├── deploy.sh
└── run.sh
```

### Running and stopping service manually

Running service:

> ./run.sh

Stopping the service:

> ./run.sh stop

<br>

### Automated deployment service

> ./deploy.sh
