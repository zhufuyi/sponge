package ecode

import (
	"github.com/zhufuyi/sponge/pkg/errcode"
)

// user rpc service level error code
var (
	_userNO       = 64 // number range 1~100, if there is the same number, trigger panic.
	_userName     = "user"
	_userBaseCode = errcode.HCode(_userNO)

	StatusRegisterUser = errcode.NewError(_userBaseCode+1, "failed to Register "+_userName)
	StatusLoginUser    = errcode.NewError(_userBaseCode+2, "failed to Login "+_userName)
	// add +1 to the previous error code
)
