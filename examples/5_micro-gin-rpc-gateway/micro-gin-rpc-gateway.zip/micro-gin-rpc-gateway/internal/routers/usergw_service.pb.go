package routers

import (
	usergwV1 "usergw/api/usergw/v1"
	"usergw/internal/service"

	"github.com/zhufuyi/sponge/pkg/logger"

	"github.com/gin-gonic/gin"
)

func init() {
	apiV1RouterFns = append(apiV1RouterFns, func(prePath string, group *gin.RouterGroup) {
		userRouter(prePath, group, service.NewUserClient())
	})
}

func userRouter(prePath string, group *gin.RouterGroup, iService usergwV1.UserLogicer) {
	usergwV1.RegisterUserRouter(prePath, group, iService,
		usergwV1.WithUserRPCResponse(),
		usergwV1.WithUserLogger(logger.Get()),
	)
}
