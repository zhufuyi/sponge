package routers

import (
	"context"
	"testing"
	"time"

	usergwV1 "usergw/api/usergw/v1"
	"usergw/configs"
	"usergw/internal/config"

	"github.com/zhufuyi/sponge/pkg/utils"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestNewRouter(t *testing.T) {
	err := config.Init(configs.Path("usergw.yml"))
	if err != nil {
		t.Fatal(err)
	}

	config.Get().App.EnableMetrics = true
	config.Get().App.EnableTrace = true
	config.Get().App.EnableHTTPProfile = true
	config.Get().App.EnableLimit = true
	config.Get().App.EnableCircuitBreaker = true

	utils.SafeRunWithTimeout(time.Second*2, func(cancel context.CancelFunc) {
		gin.SetMode(gin.ReleaseMode)
		r := NewRouter()
		assert.NotNil(t, r)
		cancel()
	})
}

func Test_userExampleServiceRouter(t *testing.T) {
	gin.SetMode(gin.ReleaseMode)
	r := gin.Default()
	rg := r.Group("")
	userExampleServiceRouter("", rg, &mockGw{})
}

type mockGw struct{}

func (m mockGw) Create(ctx context.Context, req *usergwV1.CreateUserExampleRequest) (*usergwV1.CreateUserExampleReply, error) {
	return nil, nil
}

func (m mockGw) DeleteByID(ctx context.Context, req *usergwV1.DeleteUserExampleByIDRequest) (*usergwV1.DeleteUserExampleByIDReply, error) {
	return nil, nil
}

func (m mockGw) GetByID(ctx context.Context, req *usergwV1.GetUserExampleByIDRequest) (*usergwV1.GetUserExampleByIDReply, error) {
	return nil, nil
}

func (m mockGw) List(ctx context.Context, req *usergwV1.ListUserExampleRequest) (*usergwV1.ListUserExampleReply, error) {
	return nil, nil
}

func (m mockGw) ListByIDs(ctx context.Context, req *usergwV1.ListUserExampleByIDsRequest) (*usergwV1.ListUserExampleByIDsReply, error) {
	return nil, nil
}

func (m mockGw) UpdateByID(ctx context.Context, req *usergwV1.UpdateUserExampleByIDRequest) (*usergwV1.UpdateUserExampleByIDReply, error) {
	return nil, nil
}
