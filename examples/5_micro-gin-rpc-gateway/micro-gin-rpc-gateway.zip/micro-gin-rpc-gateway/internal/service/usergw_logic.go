package service

import (
	"context"

	usergwV1 "usergw/api/usergw/v1"
	//"usergw/internal/rpcclient"
)

var _ usergwV1.UserLogicer = (*userClient)(nil)

type userClient struct {
	// defining rpc clients object

	// example:
	//userCli usergwV1.UserClient
}

// NewUserClient creating rpc clients
func NewUserClient() usergwV1.UserLogicer {
	return &userClient{
		// example:
		//userCli: usergwV1.NewUserClient(rpcclient.GetUsergwRPCConn()),
	}
}

func (c *userClient) Register(ctx context.Context, req *usergwV1.RegisterRequest) (*usergwV1.RegisterReply, error) {
	// example:
	//     return c.userCli.Register(ctx, req)

	// fill in the business logic code

	panic("implement me")
}

func (c *userClient) Login(ctx context.Context, req *usergwV1.LoginRequest) (*usergwV1.LoginReply, error) {
	// example:
	//     return c.userCli.Login(ctx, req)

	// fill in the business logic code

	panic("implement me")
}
